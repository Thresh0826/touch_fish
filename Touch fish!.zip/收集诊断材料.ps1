﻿# 一键收集诊断材料到桌面 moyu-diag 文件夹（不含业务表格内容）
# 用法：右键"使用 PowerShell 运行"，或在 PowerShell 里执行本文件
$ErrorActionPreference = 'Continue'
$src = Join-Path $env:LOCALAPPDATA 'MoyuTools'
$state = Join-Path $src 'sheet_rows_simple'
$dst = Join-Path ([Environment]::GetFolderPath('Desktop')) 'moyu-diag'
New-Item -ItemType Directory -Force -Path $dst | Out-Null

$files = @(
    (Join-Path $state 'calibration.jsonl'),
    (Join-Path $state 'window_checks.jsonl'),
    (Join-Path $state 'binding.json'),
    (Join-Path $state 'header_choice.json'),
    (Join-Path $state 'bridge_startup.txt'),
    (Join-Path $src 'worker_stderr.txt')
)
foreach ($file in $files) {
    if (Test-Path -LiteralPath $file) {
        Copy-Item -LiteralPath $file -Destination $dst -Force
        Write-Host ('collected: ' + (Split-Path $file -Leaf))
    } else {
        Write-Host ('skipped (missing): ' + (Split-Path $file -Leaf))
    }
}

# 业务系统窗口身份：只有进程号、标题、路径
$app = Get-Process -Name App -ErrorAction SilentlyContinue
if ($app) {
    $app | Select-Object Id, MainWindowTitle, Path | Format-List |
        Out-File -FilePath (Join-Path $dst 'wdms_window.txt') -Encoding UTF8
    Write-Host 'collected: wdms_window.txt'
}

# 定位项坐标（只有坐标，不含业务数据）
$bindingPath = Join-Path $state 'binding.json'
if (Test-Path -LiteralPath $bindingPath) {
    $binding = Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $lines = @()
    foreach ($name in @('start', 'end', 'contract', 'query', 'header', 'cell', 'count', 'count_label', 'conditions')) {
        $property = $binding.wdms.PSObject.Properties[$name]
        if ($null -eq $property) { continue }
        $value = $property.Value
        if ($value -is [array]) {
            $lines += ($name + ' = ' + ($value -join ','))
        } elseif ($null -ne $value.point) {
            $lines += ($name + ' = ' + ($value.point -join ','))
        }
    }
    $lines | Out-File -FilePath (Join-Path $dst 'binding_points.txt') -Encoding UTF8
    Write-Host 'collected: binding_points.txt'
}

Write-Host ''
Write-Host ('output folder: ' + $dst)
Write-Host 'NOTE: settings.json and task logs contain contract/order numbers and are NOT collected.'
Start-Sleep -Seconds 8
