# 问题说明与技术背景（转发给 GPT / Claude 用）

**一句话**：Windows 桌面自动化工具要从公司业务系统 WDMS 里读取"送货单号"，但**结果表是自绘的，列头和单元格文字都不作为控件暴露**，导致自动化读不到数据。需要外部意见：这个界面到底该怎么读。

---

## 1. 环境与目标

| 项 | 值 |
|---|---|
| 系统 | Windows 10（1366×768，DPI 96） |
| 业务系统 | WDMS「医药企业仓储运输管理系统」，进程 `App`，**WinForms（MDI）**，主窗口类名 `WindowsForms10.Window.8.app.0.378734a` |
| 目标流程 | 表格每行 → 在 WDMS 填"生成日期"起止 + "合同编号" → 点查询 → 读出结果表里的**送货单号** → 拿这个号去远程桌面 Everything 里搜 ZIP → 复制回本地 |
| 技术栈 | Python 3.13 + Tkinter 界面；通过一个常驻 PowerShell(-STA) 子进程调用 Windows API（user32 / oleacc / GDI+），Python↔PowerShell 走 JSON 行协议 |
| 权限 | 同一用户会话，无管理员权限需求，不能安装软件、不能联网 |

## 2. 已实测的事实（都是本机实测，不是推测）

**扫描性能（都不是瓶颈）**

| 测量项 | 实测值 |
|---|---|
| `EnumWindows` 枚举全部 429 个顶层窗口 | 3.6 ms |
| WDMS 控件树扫描（`EnumChildWindows` 168 个控件） | 10.8 ms |
| 整次"截图 + PNG 编码 + 控件扫描"（preview） | 2.2–3.2 s，返回 196 个控件 |
| MSAA `AccessibleObjectFromPoint` 41 点采样 | 28 ms（最慢单点 11.8 ms） |

**关键控件（实测坐标，屏幕坐标）**

```
# 查询条件区的字段标签（表单）
hwnd=132000  class=WindowsForms10.STATIC.app.0.378734a  rect=[553,212,606,224]  WM_GETTEXT='送货单号'
# 行数指示
hwnd=?(STATIC) '总行数：' rect=[857,310,910,322]
hwnd=?(STATIC) '1'        rect=[916,310,967,322]
# 结果表容器
class=WindowsForms10.Window.8.app.0.378734a  rect=[210,331,994,511]
```

**读不到的部分（核心问题）**

- 结果表的**列头文字**（"货主/送货单号/出库合同号/客商…"）**不在控件清单里**：扫描整个结果表区域（y=318~400，每 6px 一行 × 每 12px 一点）**没有任何带文字的控件**。
- 对结果表列头位置做 MSAA 点读 → 返回的是**表格容器**（`role=10 ROLE_SYSTEM_CLIENT`，name/value 都空）。
- 按句柄读容器文字 → 容器类名是 `Window.8`，不是 EDIT/STATIC/BUTTON/COMBOBOX，**无法用 `WM_GETTEXT` 读**。
- 单击结果表列头 → 命中的是容器 `rect=[210,331,994,511]`，不是一个小控件。

**能读到的部分**

- 表单里的控件都正常：日期 `DateTimePicker` 可读写（回读 `2024-01-17`）、合同编号框 `EDIT` 可读写（回读 `418781`）、查询按钮 `BUTTON`（`WM_GETTEXT` = `查询(&F)`）、行数标签与数字（`总行数：` / `1`）。
- **表头文字的读取还有一个坑**：这些标签用 **MSAA 点读拿到的是空**，必须**按控件句柄 `WM_GETTEXT`** 才能读到（已验证："总行数："、"查询(&F)"、字段标签都如此）。
- 早期一次探测中，结果表**有数据行**时，对数据行位置做 MSAA 点读是**能读到文字**的（例："003015170007"）；但表格为空时读到的只有容器。**这一点尚未稳定复现，需要进一步确认。**

## 3. 已尝试过的方案与结果

| 方案 | 结果 |
|---|---|
| 控件树扫描（`EnumChildWindows` + `WM_GETTEXT`） | 读不到结果表列头与单元格 |
| MSAA 点读（`AccessibleObjectFromPoint`） | 空表时只有容器；有数据时**曾**读到单元格文字 |
| 按句柄读文字（`WM_GETTEXT`） | 容器类不支持，失败 |
| 在结果表区域逐点扫描找"送货单号"这串文字 | 找不到 |
| 用同名文字定位列（"送货单号"在表单和列头各出现一次） | 只能找到表单那个，**列头那个不存在于控件树** |
| 屏幕像素 OCR | 本项目已有离线 OCR 通道（Windows.Media.Ocr，仅用于远程桌面侧），WDMS 侧尚未采用 |

## 4. 当前代码状态（已改的部分）

- 已**删除**"必须读出列头文字 = 送货单号"的校验（该判据在本系统上永远不成立）。
- 改为：**在结果表里点一下"送货单号"列** → 记录该位置 → 由位置推导第一行单元格坐标 → 运行时按该坐标读单号；
  读到的值必须是**纯单号格式**（`^[A-Za-z0-9][A-Za-z0-9_-]{3,79}$`），否则报错并暂停（不猜其他数字）。
- 单元测试 192 项全部通过（但这些测试全是**模拟对象**，不含真实 WDMS 行为）。

## 5. 需要外部意见的问题

1. 这个结果表最可能是什么控件（`DataGridView` / 第三方表格 / 自绘控件）？**在没有 UIA 结构、没有单元格 HWND 的前提下，最可靠的取数方式是什么？**
2. `AccessibleObjectFromPoint` 在**有数据行**时能读到单元格，是否说明该表格其实实现了 `IAccessible`？能否用 `AccessibleObjectFromWindow(hwnd, OBJID_CLIENT)` 拿到表格的 `IAccessible`，再走 `accNavigate`/`accHitTest` 枚举行列？需要注意什么（跨进程 COM、超时、崩溃风险）？
3. 若必须走像素/OCR：**如何把误读风险降到可接受**（例如用单号与合同号的对应关系做交叉校验、只 OCR 单号那一列、与"总行数"核对）？
4. 有没有办法让 WDMS 暴露更多无障碍信息（启动参数、兼容性设置、系统"辅助功能"开关）而不改动业务系统？
5. 用 `Inspect.exe`/`Accessibility Insights` 抓到的 UIA 树（若有）应该重点看什么？

## 6. 请提供的日志与材料（清单）

全部在 `%LOCALAPPDATA%\MoyuTools\` 下（`sheet_rows_simple` 子目录为当前版本）：

| 文件 | 内容 | 是否含业务信息 |
|---|---|---|
| `sheet_rows_simple\calibration.jsonl` | 定位过程中的每一步、失败原因、检查点 | 否（只有坐标/错误码） |
| `sheet_rows_simple\window_checks.jsonl` | 每次截图前后的窗口遮挡/前台/采样点判定 | 否 |
| `sheet_rows_simple\binding.json` | 成功保存后的定位结果（各项目坐标、窗口身份） | 否（坐标） |
| `sheet_rows_simple\header_choice.json` | 记住的"送货单号列"位置 | 否 |
| `sheet_rows_simple\settings.json` | 任务设置与表格快照 | **是**（含合同号、日期、路径） |
| `bridge_startup.txt` / `worker_stderr.txt` | PowerShell 助手启动失败时的原始错误 | 否 |
| 任务目录（`打开日志` 按钮进的那个）里的 `events.jsonl`、`*.console.txt`、`*.result.json` | 每次运行的逐步事件与错误 | **是**（含单号、文件名） |

**建议：只发前 5 项里的前 4 项 + 两个诊断文本**，`settings.json` 和任务目录日志先脱敏（把合同号、单号、客户名替换掉）。

另外请提供（最重要）：

1. **WDMS 定位页的截图**，要求同时看得到：查询条件区、"总行数"那一行、**结果表的完整列头**和第一行数据。
2. **结果表的列顺序**（从左到右），例如：货主 / 送货单号 / 出库合同号 / 客商 / 客商地址 / 部门…
3. 如果可以：用 **Inspect.exe**（Windows SDK 自带）或 **Accessibility Insights for Windows** 选中结果表，导出 **UIA 树**（重点：表格节点的 `ControlType`、是否 `Table`/`DataGrid`，能否展开出行/列）。
4. 结果表**有数据行**时和**空表**时，各截一张图。

## 7. 收集命令（在 PowerShell 里逐条执行）

```powershell
# 打包诊断日志（不含 settings.json 与任务目录）
$src = "$env:LOCALAPPDATA\MoyuTools"
$dst = "$env:USERPROFILE\Desktop\moyu-diag"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item "$src\sheet_rows_simple\calibration.jsonl"   $dst -ErrorAction SilentlyContinue
Copy-Item "$src\sheet_rows_simple\window_checks.jsonl" $dst -ErrorAction SilentlyContinue
Copy-Item "$src\sheet_rows_simple\binding.json"        $dst -ErrorAction SilentlyContinue
Copy-Item "$src\sheet_rows_simple\header_choice.json"  $dst -ErrorAction SilentlyContinue
Copy-Item "$src\sheet_rows_simple\bridge_startup.txt"  $dst -ErrorAction SilentlyContinue
Copy-Item "$src\worker_stderr.txt"                     $dst -ErrorAction SilentlyContinue
Get-ChildItem $dst | Select-Object Name, Length

# 业务系统的窗口身份（不含业务数据）
Get-Process App | Select-Object Id, MainWindowTitle, Path
```

## 8. 环境约束（外部建议必须满足这些）

- 不能安装任何软件/依赖，不能联网（公司现场）。
- 不能改动业务系统 WDMS 本身。
- 只能使用 Python 标准库 + 已有运行时；Windows API 通过 PowerShell 助手调用。
- 自动化必须"只读优先、绝不猜测"：读不到就停下来报错，宁可人工处理。
- 单次只读操作的原则上限：约 8 秒（父进程硬超时），超时就终止助手进程并重建。
