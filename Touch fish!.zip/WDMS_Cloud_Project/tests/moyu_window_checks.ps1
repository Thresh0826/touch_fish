$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$accessibility = [Reflection.Assembly]::Load('Accessibility, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
$moyuProject = Split-Path $PSScriptRoot -Parent
Add-Type -Path (Join-Path $moyuProject 'moyu_tools\windows_native.cs') -ReferencedAssemblies @(
    [Diagnostics.Process].Assembly.Location, [System.Windows.Forms.Clipboard].Assembly.Location,
    [Drawing.Bitmap].Assembly.Location, $accessibility.Location
)
. (Join-Path $moyuProject 'moyu_tools\window_checks.ps1')

# All window states are synthetic. No window is shown, focused, queried or read.
$script:moyuAssertions = 0
function Assert-Moyu([bool]$Condition, [string]$Name) {
    if (-not $Condition) { throw ('synthetic assertion failed: ' + $Name) }
    $script:moyuAssertions++
}
function New-MoyuState {
    $state = New-Object 'MoyuNative+WindowState'
    $state.Hwnd = 197488; $state.Pid = 4524; $state.Thread = 1
    $state.Bounds = [int[]]@(0, 0, 1024, 773); $state.RectAvailable = $true
    $state.Visible = $true; $state.Minimized = $false
    $state.Ancestor = 197488; $state.Foreground = 197488
    return $state
}
$expected = [int[]]@(0, 0, 1024, 773)
Assert-Moyu ([MoyuNative]::RootCheckReason((New-MoyuState), 4524, $expected, $true) -eq '') 'valid root'
foreach ($item in @(
    @('Thread', [uint32]0, 'window_missing'), @('Pid', [uint32]999, 'window_pid_mismatch'),
    @('RectAvailable', $false, 'window_rect_unavailable'), @('Visible', $false, 'window_not_visible'),
    @('Minimized', $true, 'window_minimized'), @('Foreground', [long]999, 'window_foreground_mismatch')
)) {
    $state = New-MoyuState
    $state.($item[0]) = $item[1]
    Assert-Moyu ([MoyuNative]::RootCheckReason($state, 4524, $expected, $true) -eq $item[2]) $item[2]
}
for ($index = 0; $index -lt 4; $index++) {
    $state = New-MoyuState
    $state.Bounds[$index]++
    Assert-Moyu ([MoyuNative]::RootCheckReason($state, 4524, $expected, $true) -eq 'window_rect_mismatch') ('exact edge ' + $index)
}
$state = New-MoyuState; $state.Foreground = 999
Assert-Moyu ([MoyuNative]::RootCheckReason($state, 4524, $expected, $false) -eq '') 'foreground optional only when requested'
Assert-Moyu ([MoyuNative]::RootCheckReason($state, 4524, ([int[]]@(0, 0)), $true) -eq 'window_expected_rect_invalid') 'invalid expected rect'
foreach ($item in @(
    @('Thread', [uint32]0, 'child_window_missing'), @('Pid', [uint32]999, 'child_pid_mismatch'),
    @('Ancestor', [long]999, 'child_root_mismatch'), @('Visible', $false, 'child_not_visible')
)) {
    $state = New-MoyuState
    $state.($item[0]) = $item[1]
    Assert-Moyu ([MoyuNative]::ChildCheckReason($state, 197488, 4524) -eq $item[2]) $item[2]
}
Assert-Moyu ([MoyuNative]::ChildCheckReason((New-MoyuState), 197488, 4524) -eq '') 'valid child'

$moyuOriginalLocalData = $env:LOCALAPPDATA
$moyuTemporary = Join-Path ([IO.Path]::GetTempPath()) ('moyu-window-checks-' + [Guid]::NewGuid().ToString('N'))
try {
    $env:LOCALAPPDATA = $moyuTemporary
    $state = New-MoyuState; $state.Hwnd = 222; $state.Ancestor = 999
    $expectedState = New-Object 'Collections.Generic.Dictionary[string,object]'
    $expectedState['root_hwnd'] = [long]197488; $expectedState['pid'] = [uint32]4524
    $failure = [MoyuNative+WindowCheckException]::new('child_root_mismatch', 'preview.before_pixels.sample', $expectedState, $state)
    $failure.Details['sample_point'] = [int[]]@(8, 30)
    $failure.Details['region'] = [int[]]@(8, 30, 1016, 765)
    $failure.Details['image'] = 'PRIVATE_CONTENT' * 10000
    $failure.Details['actual']['caption'] = 'PRIVATE_CONTENT'
    $failure.Details['actual']['path'] = 'PRIVATE_CONTENT'
    $failure.Details['expected']['contract'] = 'PRIVATE_CONTENT'
    $requestId = 'c6f2ad38-0f67-4e93-997b-23c682a0f405'
    Assert-Moyu (Write-MoyuWindowCheck 'preview_started' 'preview' $requestId 'request.decode' @{}) 'begin logged'
    Assert-Moyu (Write-MoyuWindowCheck 'check_failed' 'preview' $requestId 'request.dispatch' $failure.Details) 'failure logged'
    Assert-Moyu (Write-MoyuWindowCheck 'preview_completed' 'preview' $requestId 'request.complete' @{}) 'completion logged'
    $log = Join-Path $moyuTemporary 'MoyuTools\sheet_rows_simple\window_checks.jsonl'
    $lines = [IO.File]::ReadAllLines($log)
    Assert-Moyu ($lines.Count -eq 3) 'one line per event'
    $row = $lines[1] | ConvertFrom-Json
    Assert-Moyu ($row.request_id -eq $requestId -and $row.phase -eq 'request.dispatch') 'correlated stage'
    Assert-Moyu ($row.details.stage -eq 'preview.before_pixels.sample') 'inner stage'
    Assert-Moyu ($row.details.check -eq 'child_root_mismatch') 'specific condition'
    Assert-Moyu ($row.details.actual.hwnd -eq 222 -and $row.details.actual.ancestor_hwnd -eq 999) 'actual target preserved'
    Assert-Moyu ($row.details.expected.root_hwnd -eq 197488 -and $row.details.expected.pid -eq 4524) 'expected target preserved'
    Assert-Moyu ($row.details.sample_point.Count -eq 2 -and $row.details.region.Count -eq 4) 'sampling coordinates'
    Assert-Moyu (-not ([IO.File]::ReadAllText($log).Contains('PRIVATE_CONTENT'))) 'no raw contents'

    $unsafe = @{check='PRIVATE_CONTENT'; stage='PRIVATE_CONTENT'; actual=@{hwnd='PRIVATE_CONTENT'; rect=@('PRIVATE_CONTENT',0,1,2)}}
    Assert-Moyu (Write-MoyuWindowCheck 'PRIVATE_CONTENT' 'PRIVATE_CONTENT' 'PRIVATE_CONTENT' 'PRIVATE_CONTENT' $unsafe) 'unrecognized data sanitized'
    Assert-Moyu (-not ([IO.File]::ReadAllText($log).Contains('PRIVATE_CONTENT'))) 'no unknown strings or numeric strings'
    $row = ([IO.File]::ReadAllLines($log)[3] | ConvertFrom-Json)
    Assert-Moyu ($row.action -eq 'unknown' -and $null -eq $row.request_id) 'unknown identity omitted'

    $before = [IO.File]::ReadAllText($log)
    $lock = [IO.File]::Open($log, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    try {
        $result = Write-MoyuWindowCheck 'check_failed' 'preview' $requestId 'request.dispatch' $failure.Details
        Assert-Moyu ($result -is [bool] -and -not $result) 'write failure returns only false'
    } finally { $lock.Dispose() }
    Assert-Moyu ([IO.File]::ReadAllText($log) -eq $before) 'locked log unchanged'
    @{ok=$true; assertions=$script:moyuAssertions; native_ui_calls=0} | ConvertTo-Json -Compress
} finally {
    $env:LOCALAPPDATA = $moyuOriginalLocalData
    if (Test-Path -LiteralPath $moyuTemporary) { Remove-Item -LiteralPath $moyuTemporary -Recurse -Force }
}
