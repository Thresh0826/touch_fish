import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile


class MoyuPackagingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = Path(__file__).resolve().parents[2]
        path = root/'工具'/'打包摸鱼小工具.py'
        spec = importlib.util.spec_from_file_location('moyu_packager_for_test', path)
        cls.packager = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.packager)

    def package(self, path, *, wrong_hash=False, unsafe=False, duplicate=False, verified=False):
        files = {name: b'synthetic source' for name in self.packager.REQUIRED}
        manifest = {'product': '摸鱼小工具', 'windows_verified': verified,
                    'files': {name: self.packager.summary(data) for name, data in files.items()}}
        if wrong_hash:
            next(iter(manifest['files'].values()))['sha256'] = '0'*64
        with zipfile.ZipFile(path, 'w') as archive:
            for name, data in files.items():
                archive.writestr(name, data)
            archive.writestr('SOURCE_MANIFEST.json', json.dumps(manifest))
            if unsafe:
                archive.writestr('../escape.txt', 'synthetic')
            if duplicate:
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore', UserWarning)
                    archive.writestr(next(iter(files)), 'duplicate')

    def test_exact_member_size_hash_and_unverified_declaration(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'package.zip'
            self.package(path)
            self.assertEqual(self.packager.verify(path)['product'], '摸鱼小工具')

    def test_corrupt_manifest_different_members_and_false_verified_claim_are_rejected(self):
        for change in ('wrong_hash', 'unsafe', 'duplicate', 'verified'):
            with self.subTest(change=change), tempfile.TemporaryDirectory() as folder:
                path = Path(folder)/'package.zip'
                self.package(path, **{change: True})
                with self.assertRaises(ValueError):
                    self.packager.verify(path)

    def build_fixture(self, folder, *, changed_launcher=False):
        module = self.packager
        root = Path(folder)/'source'
        files = {name: b'synthetic source\n' for name in module.REQUIRED}
        original_root = Path(__file__).resolve().parents[2]
        files[module.LOCAL_LAUNCHER] = (original_root/module.LOCAL_LAUNCHER).read_bytes()
        for name, data in files.items():
            destination = root/name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        if changed_launcher:
            (root/module.LOCAL_LAUNCHER).write_bytes(b'changed launcher\n')
        def git(*arguments):
            if arguments == ('status', '--porcelain'):
                return ''
            if arguments == ('rev-parse', 'HEAD'):
                return 'a'*40
            if arguments == ('branch', '--show-current'):
                return 'feature/moyu-tools'
            if arguments == ('ls-files', '-z', '--', module.SOURCE):
                return '\0'.join(sorted(name for name in files if name.startswith(module.SOURCE+'/')))
            raise AssertionError(arguments)
        def show(arguments):
            self.assertEqual(arguments[3], 'show')
            return files[arguments[4].split(':', 1)[1]]
        with patch.object(module, 'ROOT', root), patch.object(module, 'git', side_effect=git), \
                patch.object(module.subprocess, 'check_output', side_effect=show):
            return module.build(Path(folder)/'output'), files

    def test_build_preserves_working_local_launcher_and_diagnostic_payload(self):
        with tempfile.TemporaryDirectory() as folder:
            result, original = self.build_fixture(folder)
            manifest = self.packager.verify(result['package'])
            self.assertEqual(manifest['recommended_launcher'], self.packager.LOCAL_LAUNCHER)
            self.assertEqual(manifest['runtime_mode'], 'existing_python')
            self.assertFalse(manifest['bundled_dependencies'])
            with zipfile.ZipFile(result['package']) as archive:
                self.assertEqual(archive.read(self.packager.LOCAL_LAUNCHER), original[self.packager.LOCAL_LAUNCHER])
                self.assertIn(b'-UseExistingPython', archive.read(self.packager.LOCAL_LAUNCHER))
                self.assertIn('WDMS_Cloud_Project/moyu_tools/window_checks.ps1', archive.namelist())
                self.assertFalse(any('/runtime/' in name for name in archive.namelist()))

    def test_unsaved_local_launcher_is_rejected_before_delivery(self):
        with tempfile.TemporaryDirectory() as folder, self.assertRaises(ValueError):
            self.build_fixture(folder, changed_launcher=True)

    def test_missing_diagnostic_helper_or_working_launcher_is_rejected(self):
        for missing in (self.packager.LOCAL_LAUNCHER, 'WDMS_Cloud_Project/moyu_tools/window_checks.ps1'):
            with self.subTest(missing=missing), tempfile.TemporaryDirectory() as folder:
                path = Path(folder)/'package.zip'
                self.package(path)
                replacement = Path(folder)/'missing.zip'
                with zipfile.ZipFile(path) as source, zipfile.ZipFile(replacement, 'w') as target:
                    for name in source.namelist():
                        if name == missing:
                            continue
                        data = source.read(name)
                        if name == 'SOURCE_MANIFEST.json':
                            manifest = json.loads(data)
                            manifest['files'].pop(missing)
                            data = json.dumps(manifest).encode('utf-8')
                        target.writestr(name, data)
                with self.assertRaises(ValueError):
                    self.packager.verify(replacement)
