"""Screenshot failure preservation and real offline Windows diagnostic contracts."""
import copy
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from errors import WDMSError
from moyu_tools.bridge import Bridge
from moyu_tools.settings import state_root
from tests.moyu_fixtures import profile

try:
    from moyu_tools.wizard import Wizard
except ImportError:
    Wizard = None


@unittest.skipIf(Wizard is None, "Tk module unavailable; no GUI is created by these tests")
class ScreenshotFailureTests(unittest.TestCase):
    def test_failed_capture_retains_markings_and_never_submits_or_retries(self):
        with tempfile.TemporaryDirectory() as folder:
            wizard = Wizard.__new__(Wizard)
            wizard.master, wizard.window, wizard.capture_button = Mock(), Mock(), Mock()
            wizard.selector = Mock()
            wizard.selector.current.return_value = 0
            root = profile()["wdms"]["root"]
            wizard.windows, wizard.role_choices = [root], {}
            wizard.busy, wizard.quitting = False, False
            wizard.key = lambda: "wdms"
            wizard.preview_size = (800, 600)
            wizard.queue, wizard.cancel = queue.Queue(), threading.Event()
            wizard.log = Path(folder)/"calibration.jsonl"
            wizard.driver, wizard.bridge = Mock(), Mock()
            message = "synthetic child_root_mismatch / preview.before_pixels.sample"
            wizard.bridge.call.side_effect = WDMSError("MOYU_NATIVE_UNAVAILABLE", message)
            wizard.snapshots = {"wdms": {"root": copy.deepcopy(root)}}
            wizard.markings = {"wdms": {"contract": {"point": [1, 2]}}, "remote": {}}
            wizard.manual = {"wdms": {"contract"}, "remote": set()}
            before = copy.deepcopy((wizard.snapshots, wizard.markings, wizard.manual))
            def immediate(target, **_kwargs):
                return Mock(start=target)
            with patch("moyu_tools.wizard.threading.Thread", side_effect=immediate), \
                    patch("moyu_tools.wizard.messagebox.showerror") as error:
                wizard.capture()
                wizard.poll()
            self.assertEqual((wizard.snapshots, wizard.markings, wizard.manual), before)
            self.assertFalse(wizard.busy)
            wizard.bridge.call.assert_called_once()
            self.assertEqual(wizard.bridge.call.call_args.args[0], "preview")
            wizard.driver.focus.assert_called_once()
            wizard.driver.click.assert_not_called()
            wizard.driver.type_text.assert_not_called()
            wizard.driver.chord.assert_not_called()
            wizard.window.after.assert_called_once()
            self.assertIn(message, error.call_args.args[1])
            records = [json.loads(line) for line in wizard.log.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(records[0]["error_code"], "MOYU_NATIVE_UNAVAILABLE")
            self.assertIn("child_root_mismatch", records[0]["error"])

    def test_distinct_failure_reason_reaches_calibration_log_without_retry(self):
        with tempfile.TemporaryDirectory() as folder:
            bridge = Bridge.__new__(Bridge)
            bridge.log, bridge.started = Path(folder)/"calibration.jsonl", True
            bridge.worker = Mock()
            message = "synthetic window_rect_mismatch / request.before"
            bridge.worker.request.side_effect = WDMSError("MOYU_NATIVE_UNAVAILABLE", message)
            with self.assertRaises(WDMSError) as caught:
                bridge.call("preview", {"root": profile()["wdms"]["root"]})
            self.assertEqual(caught.exception.message, message)
            bridge.worker.request.assert_called_once()
            bridge.worker.close.assert_not_called()
            logged = json.loads(bridge.log.read_text(encoding="utf-8"))
            self.assertEqual(logged["action"], "preview")
            self.assertIn("window_rect_mismatch", logged["error"])


@unittest.skipUnless(sys.platform == "win32", "Windows C#/PowerShell contracts require Windows; not verified on this host")
class WindowsDiagnosticTests(unittest.TestCase):
    def test_actual_csharp_predicates_and_allowlisted_ps_log_writer(self):
        project = Path(__file__).resolve().parents[1]
        powershell = Path(os.environ.get("SystemRoot", r"C:\Windows"))/"System32/WindowsPowerShell/v1.0/powershell.exe"
        result = subprocess.run([str(powershell), "-NoLogo", "-NoProfile", "-NonInteractive", "-STA",
                                 "-ExecutionPolicy", "Bypass", "-File", str(project/"tests/moyu_window_checks.ps1")],
                                cwd=project, capture_output=True, text=True, encoding="utf-8", timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertTrue(data["ok"])
        self.assertGreaterEqual(data["assertions"], 30)
        self.assertEqual(data["native_ui_calls"], 0)

    def test_real_bridge_missing_window_reports_before_phase_without_capture(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {"LOCALAPPDATA": folder}):
            log = Path(folder)/"calibration.jsonl"
            bridge = Bridge(log)
            try:
                with self.assertRaises(WDMSError) as caught:
                    bridge.call("preview", {"root": {"hwnd": 0, "pid": 0, "rect": [0, 0, 1, 1]}, "width": 800, "height": 600})
            finally:
                bridge.close()
            self.assertEqual(caught.exception.code, "MOYU_NATIVE_UNAVAILABLE")
            self.assertIn("window_missing", caught.exception.message)
            self.assertIn("request.before", caught.exception.message)
            rows = [json.loads(line) for line in (state_root()/"window_checks.jsonl").read_text(encoding="utf-8-sig").splitlines()]
            self.assertEqual([row["event"] for row in rows], ["preview_started", "check_failed"])
            self.assertEqual(rows[0]["request_id"], rows[1]["request_id"])
            self.assertEqual(rows[1]["details"]["check"], "window_missing")
            self.assertEqual(rows[1]["details"]["actual"]["hwnd"], 0)
            self.assertNotIn("image", rows[1]["details"])
