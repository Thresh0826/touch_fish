# Offline, allowlisted technical diagnostics. This file performs no UI actions.
function Copy-MoyuCoordinates($Value, [int]$Count) {
    if (-not ($Value -is [Array]) -or $Value.Count -ne $Count) { return $null }
    foreach ($number in $Value) {
        if (-not ($number -is [int] -or $number -is [uint32] -or $number -is [long])) { return $null }
    }
    return ,([long[]]$Value)
}

function Copy-MoyuWindowFields($Source, [string[]]$Integers, [string[]]$Flags, [string[]]$Rects) {
    $moyuFields = @{}
    if ($null -eq $Source) { return $moyuFields }
    foreach ($name in $Integers) {
        if (-not $Source.ContainsKey($name)) { continue }
        $number = $Source[$name]
        if ($number -is [int] -or $number -is [uint32] -or $number -is [long]) { $moyuFields[$name] = $number }
    }
    foreach ($name in $Flags) {
        if (-not $Source.ContainsKey($name)) { continue }
        if ($Source[$name] -is [bool]) { $moyuFields[$name] = $Source[$name] }
    }
    foreach ($name in $Rects) {
        if (-not $Source.ContainsKey($name)) { continue }
        $coordinates = Copy-MoyuCoordinates ($Source[$name]) 4
        if ($null -ne $coordinates) { $moyuFields[$name] = $coordinates }
    }
    return $moyuFields
}

function ConvertTo-MoyuWindowDetails([System.Collections.IDictionary]$Details) {
    $moyuDetails = @{}
    $moyuChecks = @('window_expected_rect_invalid', 'window_missing', 'window_pid_mismatch',
        'window_rect_unavailable', 'window_not_visible', 'window_minimized', 'window_rect_mismatch',
        'window_foreground_mismatch', 'child_window_missing', 'child_pid_mismatch', 'child_root_mismatch',
        'child_not_visible', 'client_rect_unavailable', 'client_origin_unavailable', 'window_obscured')
    if ($null -eq $Details) { return $moyuDetails }
    if ($moyuChecks -contains $Details['check']) { $moyuDetails['check'] = [string]$Details['check'] }
    $stage = [string]$Details['stage']
    if ($stage -match '\A(?:root_guard|child_guard|request\.(?:before|after)|read_point\.(?:before|after)|capture\.area(?:\.(?:sample|overlap))?|preview\.(?:client_rect|client_origin|(?:before_pixels|after_controls)\.(?:sample|overlap)))\z') {
        $moyuDetails['stage'] = $stage
    }
    $moyuDetails['expected'] = Copy-MoyuWindowFields $Details['expected'] @('hwnd', 'root_hwnd', 'pid') @('foreground_required') @('rect', 'region')
    $moyuDetails['actual'] = Copy-MoyuWindowFields $Details['actual'] @('hwnd', 'pid', 'thread_id', 'ancestor_hwnd', 'foreground_hwnd') @('rect_available', 'visible', 'minimized') @('rect')
    foreach ($name in @('sample_point', 'region')) {
        if (-not $Details.ContainsKey($name)) { continue }
        $count = if ($name -eq 'sample_point') { 2 } else { 4 }
        $coordinates = Copy-MoyuCoordinates ($Details[$name]) $count
        if ($null -ne $coordinates) { $moyuDetails[$name] = $coordinates }
    }
    return $moyuDetails
}

function Write-MoyuWindowCheck([string]$EventName, [string]$ActionName, [string]$RequestId, [string]$Phase, [System.Collections.IDictionary]$Details) {
    try {
        $moyuActions = @('windows', 'preview', 'point', 'read', 'date', 'edit', 'scroll', 'hash', 'conditions',
            'ocr', 'clear', 'text', 'file', 'open_folder', 'navigate_folder', 'folder', 'close')
        if ($moyuActions -notcontains $ActionName) { $ActionName = 'unknown' }
        if (@('preview_started', 'preview_completed', 'check_failed', 'preview_failed') -notcontains $EventName) { $EventName = 'unknown' }
        if (@('request.decode', 'request.before', 'request.dispatch', 'request.after', 'request.complete') -notcontains $Phase) { $Phase = 'unknown' }
        $moyuRecord = @{schema=1; diagnostics_revision='moyu-window-checks-v1'; time=[DateTimeOffset]::Now.ToString('o'); event=$EventName; action=$ActionName; phase=$Phase;
            details=(ConvertTo-MoyuWindowDetails $Details)}
        $moyuId = [Guid]::Empty
        if ([Guid]::TryParse($RequestId, [ref]$moyuId)) { $moyuRecord['request_id'] = $moyuId.ToString() }
        $moyuLine = ($moyuRecord | ConvertTo-Json -Depth 10 -Compress) + [Environment]::NewLine
        if ($moyuLine.Length -gt 8192) { return $false }
        $moyuFolder = Join-Path $env:LOCALAPPDATA 'MoyuTools\sheet_rows_simple'
        $null = [IO.Directory]::CreateDirectory($moyuFolder)
        [IO.File]::AppendAllText((Join-Path $moyuFolder 'window_checks.jsonl'), $moyuLine, (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch {
        # A locked or unwritable log must never replace the original guard failure.
        # Do not send diagnostic exceptions to stdout: it is the JSON protocol pipe.
        return $false
    }
}
