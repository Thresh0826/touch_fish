"""Snapshot geometry and conservative native candidates, independent of Tk/Win32."""
from __future__ import annotations

import copy
import json
import re

from moyu_tools.model import fail
from moyu_tools.settings import state_root

FIELDS = (
    ("start", "开始日期", "point"), ("end", "截止日期", "point"),
    ("contract", "合同编号输入框", "point"), ("query", "查询按钮", "point"),
    ("header", "送货单号表头（点结果表那一列）", "point"),
)
# Not asked for on the location page any more. They are still derived from the marks
# above (or read from the same window) and only appear as an override when the
# automatic value cannot be confirmed, so a run never depends on marking them.
EXTRA_FIELDS = (
    ("contract_label", "合同编号文字", "point"),
    ("count", "上方送货单总行数", "point"),
    ("count_label", "上方总行数文字", "point"),
    ("cell", "第一行单号位置", "point"),
    ("conditions", "整个查询条件区", "rect"),
)
REMOTE_FIELDS = (("search", "搜索输入框", "rect"), ("results", "ZIP结果列表", "rect"))
REMOTE_EXTRA_FIELDS = (("anchor", "远程固定标识", "rect"),)


def all_fields(section):
    return (FIELDS + EXTRA_FIELDS) if section == "wdms" else (REMOTE_FIELDS + REMOTE_EXTRA_FIELDS)


def extra_fields(section):
    return EXTRA_FIELDS if section == "wdms" else REMOTE_EXTRA_FIELDS


def screen_point(snapshot, x, y):
    width, height = snapshot["width"], snapshot["height"]
    if not (0 <= x < width and 0 <= y < height):
        fail("MOYU_POINT_INVALID", "请在截图内点选。")
    left, top, right, bottom = snapshot["source_rect"]
    return [left+int(x*(right-left)/width), top+int(y*(bottom-top)/height)]


def screen_rect(snapshot, first, last):
    a, b = screen_point(snapshot, *first), screen_point(snapshot, *last)
    rect = [min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])]
    if rect[2]-rect[0] < 4 or rect[3]-rect[1] < 4:
        fail("MOYU_POINT_INVALID", "请拖出完整的区域。")
    return rect


def canvas_rect(snapshot, rect):
    left, top, right, bottom = snapshot["source_rect"]
    return [(rect[0]-left)*snapshot["width"]/(right-left), (rect[1]-top)*snapshot["height"]/(bottom-top),
            (rect[2]-left)*snapshot["width"]/(right-left), (rect[3]-top)*snapshot["height"]/(bottom-top)]


def target_at(snapshot, point):
    candidates = [item for item in snapshot["controls"] if item["rect"][0] <= point[0] < item["rect"][2]
                  and item["rect"][1] <= point[1] < item["rect"][3]]
    target = min(candidates, key=lambda item: (item["rect"][2]-item["rect"][0])*(item["rect"][3]-item["rect"][1])) if candidates else snapshot["root"]
    return {**copy.deepcopy(target), "point": list(point)}


# Control classes whose text can be read back by handle.
TEXT_CLASSES = ("EDIT", "STATIC", "BUTTON", "COMBOBOX")


def read_text_class(control):
    return any(re.fullmatch(r"(?:.*\.)?%s(?:\..*)?" % name, control.get("class_name") or "", re.IGNORECASE)
               for name in TEXT_CLASSES)


# Accessible roles Windows uses for a table header and a table cell.
HEADER_ROLES = (25, 41, 42)
CELL_ROLES = (29, 41, 42)


def holds(item, point):
    rect = item.get("rect")
    return (isinstance(rect, list) and len(rect) == 4
            and rect[0] <= point[0] < rect[2] and rect[1] <= point[1] < rect[3])


def column_below(controls, label):
    """Point just under a label, and the smallest controls containing it."""
    rect = label["rect"]
    x = (rect[0]+rect[2])//2
    y = rect[3]+max(8, (rect[3]-rect[1])//2)
    below = [item for item in controls if holds(item, (x, y))]
    below.sort(key=lambda item: (item["rect"][2]-item["rect"][0])*(item["rect"][3]-item["rect"][1]))
    return [x, y], below


def smallest_at(snapshot, point):
    """Smallest control at a point, preferring one whose text can be read by handle.

    A click on a grid cell resolves to the grid window itself, which has no readable
    text; snapping to the label drawn there keeps a manual mark usable.
    """
    candidates = [item for item in snapshot["controls"]
                  if isinstance(item.get("rect"), list) and len(item["rect"]) == 4
                  and item["rect"][0] <= point[0] < item["rect"][2] and item["rect"][1] <= point[1] < item["rect"][3]]
    readable = [item for item in candidates if read_text_class(item)]
    pool = readable or candidates
    if not pool:
        return target_at(snapshot, point)
    smallest = min(pool, key=lambda item: (item["rect"][2]-item["rect"][0])*(item["rect"][3]-item["rect"][1]))
    return {**copy.deepcopy(smallest), "point": list(point)}


def refresh_marks(snapshot, found):
    return {key: target_at(snapshot, value["point"]) if isinstance(value, dict) else copy.deepcopy(value)
            for key, value in found.items()}


def normalize(text):
    return re.sub(r"\s", "", text or "").replace("&", "").rstrip(":：")


def automatic(snapshot):
    controls, found = snapshot["controls"], {}
    # Detected items must really be inside the selected window: WinForms keeps
    # off-screen and parked controls (e.g. a hidden 总行数 label at x=-112) in the
    # same process, and they must never be offered as a location.
    bounds = snapshot["root"]["rect"]
    def inside(item):
        point = item.get("point")
        return (isinstance(point, list) and len(point) == 2
                and bounds[0] <= point[0] < bounds[2] and bounds[1] <= point[1] < bounds[3])
    controls = [item for item in controls if inside(item)]
    def unique(key, values):
        if len(values) == 1:
            found[key] = copy.deepcopy(values[0])
    dates = sorted([item for item in controls if "datetimepick" in item["class_name"].casefold()], key=lambda item: item["point"][0])
    if len(dates) == 2 and abs(dates[0]["point"][1]-dates[1]["point"][1]) < 30:
        found.update(start=copy.deepcopy(dates[0]), end=copy.deepcopy(dates[1]))
    unique("contract_label", [item for item in controls if normalize(item.get("text")) == "合同编号"])
    if "contract_label" in found:
        x, y = found["contract_label"]["point"]
        edits = [item for item in controls if re.fullmatch(r"(?:.*\.)?EDIT(?:\..*)?", item["class_name"], re.IGNORECASE)
                 and item["rect"][0] > x and abs(item["point"][1]-y) < 20]
        if edits:
            distance = min(item["rect"][0] for item in edits)
            unique("contract", [item for item in edits if item["rect"][0] == distance])
    unique("query", [item for item in controls if re.fullmatch(r"查询(?:[（(][A-Za-z][）)])?", normalize(item.get("text")))])
    totals = sorted([item for item in controls if re.fullmatch(r"总行数[:：]?(?:[0-9]+行?)?", normalize(item.get("text")))], key=lambda item: item["point"][1])
    if totals:
        found["count_label"] = copy.deepcopy(totals[0])
        label = totals[0]
        digits = [item for item in controls if re.fullmatch(r"[0-9]+(?:行)?", normalize(item.get("text")))
                  and item["rect"][0] > label["point"][0] and abs(item["point"][1]-label["point"][1]) < 20]
        if digits:
            distance = min(item["rect"][0] for item in digits)
            unique("count", [item for item in digits if item["rect"][0] == distance])
    groups = [item for item in controls if normalize(item.get("text")) == "查询条件"]
    if len(groups) == 1:
        found["conditions"] = list(groups[0]["rect"])
    for key in ("header", "cell"):
        unique(key, [item for item in controls if item.get("hint") == key])
    # The results table paints its own column header, so the scan only ever reports the
    # form field label of the same name. Never guess the header: reuse the mark the
    # operator placed earlier, otherwise leave it for the operator to click.
    if "header" not in found:
        remembered = apply_header_choice(snapshot)
        if remembered is not None:
            found["header"] = remembered
            if "cell" not in found:
                point, below = column_below(controls, remembered)
                if below:
                    cell = copy.deepcopy(min(below, key=lambda item: item["rect"][1]))
                    cell["hint"] = "cell"
                    cell["point"] = point
                    found["cell"] = cell
    return found


def fill_derived(snapshot, found):
    if "header" in found and "cell" not in found:
        rect = found["header"].get("accessible_rect") or found["header"].get("rect")
        # The actual MSAA cell and its column bounds are checked after querying.
        if isinstance(rect, list) and len(rect) == 4:
            y = rect[3]+max(8, (rect[3]-rect[1])//2)
            x = (rect[0]+rect[2])//2
            found["cell"] = target_at(snapshot, [x, y])
            found["cell"]["point"] = [x, y]
        else:
            y = found["header"]["point"][1]+max(16, int(22*snapshot["root"]["dpi"]/96))
            found["cell"] = target_at(snapshot, [found["header"]["point"][0], y])
    if "search" in found and "anchor" not in found:
        x1, y1, x2, _ = found["search"]
        area = snapshot["source_rect"]
        top = max(area[1], y1-28)
        if y1-top >= 8:
            found["anchor"] = [x1, top, min(x2, x1+180), y1-2]
    return found


# The results table paints its own column header, so the scan only ever sees the form
# field label of the same name. The operator's choice is remembered as an offset inside
# the window and reused for every later capture of the same window shape.
HEADER_CHOICE = "header_choice.json"


def header_choice_path():
    return state_root()/HEADER_CHOICE


def load_header_choice():
    try:
        data = json.loads(header_choice_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    rect, offset = data.get("rect"), data.get("offset")
    if (not isinstance(rect, list) or len(rect) != 4
            or not isinstance(offset, list) or len(offset) != 4):
        return None
    return data


def store_header_choice(header, window):
    """Remember a mark the operator placed, relative to the window, for later captures."""
    rect, bounds = header.get("rect"), window.get("rect")
    if (not isinstance(rect, list) or len(rect) != 4
            or not isinstance(bounds, list) or len(bounds) != 4):
        return
    try:
        state_root().mkdir(parents=True, exist_ok=True)
        header_choice_path().write_text(json.dumps({
            "class_name": window.get("class_name"), "dpi": window.get("dpi"), "rect": rect,
            "offset": [rect[i]-bounds[i] for i in range(4)],
        }, ensure_ascii=False), encoding="utf-8")
    except OSError:
        # Remembering the choice is a convenience; a read-only state folder must not block.
        pass


def apply_header_choice(snapshot):
    """The remembered column header, resolved for this capture, or None."""
    choice = load_header_choice()
    if choice is None:
        return None
    root = snapshot["root"]
    if choice.get("class_name") != root.get("class_name") or choice.get("dpi") != root.get("dpi"):
        return None
    bounds, offset = root["rect"], choice["offset"]
    rect = [bounds[i]+offset[i] for i in range(4)]
    point = [(rect[0]+rect[2])//2, (rect[1]+rect[3])//2]
    if not holds({"rect": bounds}, point):
        return None
    candidates = [item for item in snapshot["controls"]
                  if isinstance(item.get("rect"), list) and len(item["rect"]) == 4
                  and holds(item, point)]
    if not candidates:
        return None
    smallest = min(candidates, key=lambda item: (item["rect"][2]-item["rect"][0])*(item["rect"][3]-item["rect"][1]))
    if smallest["rect"] != rect:
        return None
    chosen = copy.deepcopy(smallest)
    chosen["hint"] = "header"
    chosen["operator_placed"] = True
    return chosen
